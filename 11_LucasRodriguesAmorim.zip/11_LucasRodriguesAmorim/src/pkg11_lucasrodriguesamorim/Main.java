
package pkg11_lucasrodriguesamorim;

import java.util.Scanner;


public class Main {

    
    public static void main(String[] args) {
        
        Scanner scannerL = new Scanner (System.in);
        int year;
        int mon;
        int days;
        int anoDias;
        int mesesDias;
        int idadeDias;
        
        System.out.println("Coloque sua idade expressa em anos, meses e diase veja quantos dias tu está sobrevivendo");
        System.out.print("Anos: ");
        year = scannerL.nextInt();
        System.out.print("Meses: ");
        mon = scannerL.nextInt();
        System.out.print("Dias :");
        days = scannerL.nextInt();
        
        if (year < 0 || mon < 0 || days < 0){
        System.out.println("Dados Inválidos");
        System.exit(0);
        };
        
        anoDias = year*365;
        mesesDias = mon*30;
        idadeDias = anoDias + mesesDias + days;
                System.out.println("Sua idade em dias é " +idadeDias+"dias de vida, até agora...");
        
        
    }
    
}
