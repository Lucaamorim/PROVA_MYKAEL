/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg13_lucasrodriguesamorim;

import javax.swing.JOptionPane;


public class Main {
 
    public static void main(String[] args) {
        
        String input = JOptionPane.showInputDialog("Insira um numero interio e diremos a voce o seu antecessor e seu sucessor!");
        int numero = Integer.parseInt(input);
        
        int numeroA = numero - 1;
        int numeroS = numero + 1;
       
        JOptionPane.showMessageDialog(null,"antecessor: "  +numeroA+ "   sucessor: " +numeroS);
       
       
    }
    
}
