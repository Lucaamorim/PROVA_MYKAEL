/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg14_lucasrodriguesamorim;

import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class Main {

    
    public static void main(String[] args) {
        Scanner scannerL = new Scanner (System.in);
        int user;
        int senha;
        
        System.out.print("Usuario:");
        user = scannerL.nextInt();
        if (user == 1234){
        System.out.print("Senha:");
        senha = scannerL.nextInt();
        if (senha == 9999){
        System.out.print("Acesso Liberado!");
        }else{
        System.out.print("Senha inválida!");
        }
        } else {
        System.out.print("Usuário inválido!");
        }
        
        
        
    }
    
}
